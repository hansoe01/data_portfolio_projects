USE jc45db;

/* Disable foreign key checks to accurately drop all tables */
SET FOREIGN_KEY_CHECKS = 0;

/* Drop any existing tables. Child tables first, then parents */
DROP TABLE IF EXISTS OtherContributions;
DROP TABLE IF EXISTS Contributions;
DROP TABLE IF EXISTS Affiliation;
DROP TABLE IF EXISTS PersonAward;
DROP TABLE IF EXISTS ManagementLog;
DROP TABLE IF EXISTS Works;
DROP TABLE IF EXISTS Award;
DROP TABLE IF EXISTS Person;
DROP TABLE IF EXISTS `Domain`;
DROP TABLE IF EXISTS Nationality;
DROP TABLE IF EXISTS Organization;
DROP TABLE IF EXISTS `User`;
DROP TABLE IF EXISTS Authorship;

/* user_id must be unique and auto-incremented.
   username must be unique; password and access_level NOT NULL. */
CREATE TABLE `User`(
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    access_level ENUM('admin', 'editor', 'viewer') NOT NULL
);

/* org_id auto-increments, url is unique. */
CREATE TABLE Organization(
    org_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(200) NOT NULL,
    country VARCHAR(50) NOT NULL,
    org_type VARCHAR(50),
    url VARCHAR(300) UNIQUE
);

/* nationality_id auto-increments, name NOT NULL + UNIQUE. */
CREATE TABLE Nationality(
    nationality_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) UNIQUE NOT NULL
);


/* domain_id auto-increments, name NOT NULL + UNIQUE. */
CREATE TABLE `Domain`(
    domain_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(30) UNIQUE NOT NULL
);


/* person_id auto-increments. active years are 4-digit years. */
CREATE TABLE Person(
    person_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    date_of_birth DATE NOT NULL,
    active_start_year INT CHECK (active_start_year BETWEEN 1000 AND 9999),
    active_end_year   INT CHECK (active_end_year   BETWEEN 1000 AND 9999),
    bio_url VARCHAR(300) UNIQUE,
    domain_id INT,
    nationality_id INT NOT NULL,
    FOREIGN KEY (domain_id)
        REFERENCES Domain(domain_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE,
    FOREIGN KEY (nationality_id)
        REFERENCES Nationality(nationality_id)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
);


/* work_type is an ENUM based on your description. */
CREATE TABLE Works(
    work_id INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(300) NOT NULL,
    pub_year INT,
    url VARCHAR(300),
    work_type ENUM('paper', 'book', 'standard', 'software',
                   'report', 'thesis', 'talk', 'other') NOT NULL
);


CREATE TABLE Award(
    award_id INT PRIMARY KEY AUTO_INCREMENT,
    award_name VARCHAR(200) NOT NULL,
    category   VARCHAR(100),
    year_awarded INT,
    UNIQUE KEY (award_name)
);

CREATE TABLE PersonAward(
    person_id INT NOT NULL,
    award_id  INT NOT NULL,
    award_year INT,
    PRIMARY KEY (person_id, award_id),
    FOREIGN KEY (person_id) REFERENCES Person(person_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (award_id) REFERENCES Award(award_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);


/* log_id auto-increments. Relates actions done by a User (and optionally about a Person). */
CREATE TABLE ManagementLog(
    log_id INT PRIMARY KEY AUTO_INCREMENT,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    activity_type VARCHAR(50) NOT NULL,
    details TEXT,
    user_id INT NOT NULL,
    person_id INT NULL,
    FOREIGN KEY (user_id) REFERENCES `User`(user_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (person_id) REFERENCES Person(person_id)
        ON DELETE SET NULL
        ON UPDATE CASCADE
);


/* Bridge table for M:N relationship between Person and Organization. */
CREATE TABLE Affiliation(
    person_id INT NOT NULL,
    org_id INT NOT NULL,
    title VARCHAR(100),
    active_start_year INT CHECK (active_start_year BETWEEN 1000 AND 9999),
    active_end_year   INT CHECK (active_end_year   BETWEEN 1000 AND 9999),
    PRIMARY KEY (person_id, org_id),
    FOREIGN KEY (person_id) REFERENCES Person(person_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (org_id) REFERENCES Organization(org_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);


/* cont_id auto-increments; contributions themselves independent. */
CREATE TABLE Contributions(
    cont_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(25) NOT NULL,
    role VARCHAR(20),
    org VARCHAR(20),
    year INT,
    type VARCHAR(20) NOT NULL
);

/* OtherContributions: bridge M:N between Person and Contributions. */
CREATE TABLE OtherContributions(
    person_id INT NOT NULL,
    cont_id INT NOT NULL,
    PRIMARY KEY (person_id, cont_id),
    FOREIGN KEY (person_id) REFERENCES Person(person_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE,
    FOREIGN KEY (cont_id) REFERENCES Contributions(cont_id)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);

/* Bridge table for M:N relationship between Person and Works*/
Create TABLE Authorship(
	person_id INT NOT NULL,
	work_id INT NOT NULL,
	PRIMARY KEY (person_id, work_id),
	FOREIGN KEY (person_id) REFERENCES Person(person_id)
	        ON DELETE CASCADE
        	ON UPDATE CASCADE,
        FOREIGN KEY (work_id) REFERENCES Works(work_id)
);

/* Re enable FK checks */
SET FOREIGN_KEY_CHECKS = 1;
