<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Display All Influential People (Wide Format)</title>
    <style>
        /* SIMPLE, FLAT DESIGN */
        body { 
            font-family: Arial, sans-serif; 
            margin: 20px; 
            background-color: #ffffff; 
            color: #000;
        }
        h1 { color: #000; font-size: 24px; margin-bottom: 10px; }
        
        /* Basic Table Styling */
        table { 
            border-collapse: collapse; 
            width: 100%; 
            min-width: 1000px; 
            font-size: 12px; 
            border: 1px solid #ccc;
        }
        
        th, td { 
            border: 1px solid #ccc; 
            padding: 8px; 
            text-align: left; 
            vertical-align: top;
        }
        
        th { 
            background-color: #0044cc; /* Standard Dark Blue Header */
            color: white; 
            font-weight: bold;
        }
        
        /* Simple Alternating Rows */
        tr:nth-child(even) { background-color: #f2f2f2; }
        
        /* Links */
        a { text-decoration: underline; color: blue; }
        a:hover { text-decoration: none; }
        
        /* Helper to keep years on one line */
        .year-col { white-space: nowrap; }
    </style>
</head>
<body>
    <h1>Database Records: Comprehensive Wide View</h1>
    
    <?php
    // 1. ENABLE ERROR REPORTING
    ini_set('display_errors', 1);
    error_reporting(E_ALL);

    include 'dbstars.php'; 
    
    try {
        $query = "
            SELECT  
                P.person_id, P.name AS PersonName, D.name AS PrimaryDomain, N.name AS Nationality, P.active_start_year AS PersonActiveSince,
                O.name AS OrganizationName, A.title AS AffiliationTitle, A.active_start_year AS AffilStart,  
                AW.award_name, PA.award_year,
                W.title AS WorkTitle, W.pub_year,
                C.name AS ContributionTitle, C.year AS ContribYear
            FROM Person P
            LEFT JOIN Domain D ON P.domain_id = D.domain_id
            LEFT JOIN Nationality N ON P.nationality_id = N.nationality_id
            LEFT JOIN Affiliation A ON P.person_id = A.person_id
            LEFT JOIN Organization O ON A.org_id = O.org_id
            LEFT JOIN PersonAward PA ON P.person_id = PA.person_id
            LEFT JOIN Award AW ON PA.award_id = AW.award_id
            LEFT JOIN Authorship ATH ON P.person_id = ATH.person_id
            LEFT JOIN Works W ON ATH.work_id = W.work_id
            LEFT JOIN OtherContributions OC ON P.person_id = OC.person_id
            LEFT JOIN Contributions C ON OC.cont_id = C.cont_id
            ORDER BY P.person_id ASC
        ";
        
        $stmt = $conn->query($query);
        $stmt->setFetchMode(PDO::FETCH_ASSOC);

        echo "<table>\n";
        echo "<tr>
                <th>ID</th>
                <th>Name</th>
                <th>Domain</th>
                <th>Nationality</th>
                <th>Active</th>
                <th>Organization</th>
                <th>Title</th>
                <th>Start</th>
                <th>Award Name</th>
                <th>Year</th>
                <th>Work Title</th>
                <th>Year</th>
                <th>Contribution</th>
                <th>Year</th>
              </tr>\n";

        while ($row = $stmt->fetch()) {
            // Safe handling for null values
            $orgName = isset($row['OrganizationName']) ? $row['OrganizationName'] : '';
            $affilStart = isset($row['AffilStart']) ? $row['AffilStart'] : '-';
            $workTitle = isset($row['WorkTitle']) ? $row['WorkTitle'] : '';
            $contrib = isset($row['ContributionTitle']) ? $row['ContributionTitle'] : '';
            $awardName = isset($row['award_name']) ? $row['award_name'] : '';
            $awardYear = isset($row['award_year']) ? $row['award_year'] : '';
            $pubYear = isset($row['pub_year']) ? $row['pub_year'] : '';
            $contribYear = isset($row['ContribYear']) ? $row['ContribYear'] : '';

            echo "<tr>";
            echo "<td>" . $row['person_id'] . "</td>";
            echo "<td>" . $row['PersonName'] . "</td>";
            echo "<td>" . $row['PrimaryDomain'] . "</td>";
            echo "<td>" . $row['Nationality'] . "</td>";
            echo "<td class='year-col'>" . $row['PersonActiveSince'] . "</td>";
            echo "<td>" . $orgName . "</td>";
            echo "<td>" . $row['AffiliationTitle'] . "</td>";
            echo "<td class='year-col'>" . $affilStart . "</td>";
            echo "<td>" . $awardName . "</td>";
            echo "<td class='year-col'>" . $awardYear . "</td>";
            echo "<td>" . $workTitle . "</td>";
            echo "<td class='year-col'>" . $pubYear . "</td>";
            echo "<td>" . $contrib . "</td>";
            echo "<td class='year-col'>" . $contribYear . "</td>";
            echo "</tr>\n";
        }
        echo "</table>\n";
    }
    catch(PDOException $e) {
        echo "<p style='color:red'>Database Error: " . $e->getMessage() . "</p>";
    }
    ?>
    
    <p style="margin-top: 20px;"><a href="index.html">Back to Home</a></p>
</body>
</html>