<!DOCTYPE html> 
<html> 
<head> 
    <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" /> 
    <title>Delete Person</title> 
</head> 
<body> 
<div style="width:30%; float:left"> 
</div>

<form action="person_delete.php" method="post"> 
    <h2>Delete a Person</h2> 
    <p>Please select the name of the person to delete:</p> 

    <?php
    include_once 'dbstars.php';
    $stmt = $conn->query("SELECT name FROM Person ORDER BY name");
    ?>

    Name: 
    <select name="name" required>
        <option value="">-- choose a person --</option>
        <?php
        while ($row = $stmt->fetch(PDO::FETCH_NUM)) {
            echo "<option value=\"" . htmlspecialchars($row[0]) . "\">" .
                    htmlspecialchars($row[0]) .
                 "</option>";
        }
        ?>
    </select>

    <br><br> 
    <input type="submit" value="Delete" />
    <input type="reset" />
</form> 

</body> 
</html>
