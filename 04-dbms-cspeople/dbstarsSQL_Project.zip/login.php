<?php
// login.php

// Database connection settings
$host = "localhost"; 
$dbname = "jc45db"; 
$user = "jc45";   
$pass = "password"; 

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Start session
session_start();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $inputUser = $_POST['username'];
    $inputPass = $_POST['password'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("SELECT User_id, password FROM User WHERE username = ?");
    $stmt->bind_param("s", $inputUser);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($userId, $hashedPassword);
        $stmt->fetch();

        // Verify password (assuming passwords are hashed with password_hash)
        if (password_verify($inputPass, $hashedPassword)) {
            // Set session variables
            $_SESSION['User_id'] = $userId;
            $_SESSION['username'] = $inputUser;

            // Log the login activity in ManagementLog
            $logStmt = $conn->prepare("INSERT INTO ManagementLog (Activity_type, Details, User_id) VALUES (?, ?, ?)");
            $activity = "Login";
            $details  = "User logged in successfully";
            $logStmt->bind_param("ssi", $activity, $details, $userId);
            $logStmt->execute();
            $logStmt->close();

            echo "Login successful. Welcome, " . htmlspecialchars($inputUser) . "!";
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with that username.";
    }

    $stmt->close();
}

$conn->close();
?>
