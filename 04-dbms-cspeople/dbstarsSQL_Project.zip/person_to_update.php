<?php 
 include_once 'dbstars.php'; 
 include 'person_display.php'; 
 echo "<h2> Display the information </h2>"; 
 display("SELECT * FROM Person;"); 
?> 

<br/> 
<form action="fill_to_update_person.php" method="post"> 
<h2>ID to Select: </h2> 
ID: <input type="text" name="person_id"/><br> 
<input type="Submit" value= "Select"/><input type="Reset"/> 
</form>
