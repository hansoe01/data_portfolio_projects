<?php 
include_once 'dbstars.php';

# form data 
$name = $_POST['name'];

$sql = "DELETE FROM Person WHERE name = :name;"; 
$stmt = $conn->prepare($sql); 

# data stored in an associative array 
$data = array('name' => $name); 

if ($stmt->execute($data)) { 
    $rows_affected = $stmt->rowCount(); 
    echo "<h2>" . $rows_affected . " row(s) deleted successfully!</h2>"; 

    $stmt = $conn->query("SELECT person_id, name, active_start_year, active_end_year FROM Person"); 

    $stmt->setFetchMode(PDO::FETCH_NUM); 

    echo "<table border=\"1\">\n"; 
    echo "<tr>
            <td>Person ID</td>
            <td>Name</td>
            <td>Active Start</td>
            <td>Active End</td>
          </tr>\n";

    while ($row = $stmt->fetch()) { 
        printf(
            "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>\n",
            $row[0],  # person_id
            $row[1],  # name
            $row[2],  # active_start_year
            $row[3]   # active_end_year
        ); 
    } 
    echo "</table>\n"; 
} 
else { 
    echo "\nPDOStatement::errorInfo():\n"; 
    print_r($stmt->errorInfo()); 
}

$stmt = null; 
$conn = null; 
?>
