<form action="updated_person.php" method="post"> 
<?php 
include_once 'dbstars.php'; 

$person_id = $_POST['person_id']; 

$query = "SELECT person_id, name, date_of_birth, active_start_year, 
                 active_end_year, bio_url, domain_id, nationality_id
          FROM Person
          WHERE person_id = ?;"; 

$stmt = $conn->prepare($query); 
$stmt->bindValue(1, $person_id, PDO::PARAM_INT);
$stmt->execute(); 
$stmt->setFetchMode(PDO::FETCH_NUM); 
$row = $stmt->fetch(); 


printf("<input type=\"hidden\" name=\"person_id\" value=\"%s\"/><br>\n", $row[0]);
printf("Name: <input type=\"text\" name=\"name\" value=\"%s\"/><br>\n", $row[1]);
printf("Date of Birth (YYYY-MM-DD): <input type=\"text\" name=\"date_of_birth\" value=\"%s\"/><br>\n", $row[2]);
printf("Active Start Year: <input type=\"number\" name=\"active_start_year\" value=\"%s\"/><br>\n", $row[3]);
printf("Active End Year: <input type=\"number\" name=\"active_end_year\" value=\"%s\"/><br>\n", $row[4]);
printf("Bio URL: <input type=\"text\" name=\"bio_url\" value=\"%s\"/><br>\n", $row[5]);
printf("Domain ID: <input type=\"number\" name=\"domain_id\" value=\"%s\"/><br>\n", $row[6]);
printf("Nationality ID: <input type=\"number\" name=\"nationality_id\" value=\"%s\"/><br>\n", $row[7]);

?> 
<br/> 
<input type="Submit" value="Update"/><input type="Reset"/> 
</form>

