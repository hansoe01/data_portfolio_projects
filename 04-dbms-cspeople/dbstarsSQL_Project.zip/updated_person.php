<?php 
include_once 'dbstars.php'; 
include_once 'display.php';

# form data 
$person_id         = $_POST['person_id'];
$name              = $_POST['name'];
$date_of_birth     = $_POST['date_of_birth'];
$active_start_year = $_POST['active_start_year'];
$active_end_year   = $_POST['active_end_year'];
$bio_url           = $_POST['bio_url'];
$domain_id         = $_POST['domain_id'];
$nationality_id    = $_POST['nationality_id'];

$sql = "update Person 
        set name = :name, 
            date_of_birth = :dob, 
            active_start_year = :start_year, 
            active_end_year = :end_year, 
            bio_url = :bio, 
            domain_id = :domain, 
            nationality_id = :nation 
        where person_id = :id"; 

$stmt = $conn->prepare($sql); 

$data = array(
    'name'       => $name,
    'dob'        => $date_of_birth,
    'start_year' => $active_start_year,
    'end_year'   => $active_end_year,
    'bio'        => $bio_url,
    'domain'     => $domain_id,
    'nation'     => $nationality_id,
    'id'         => $person_id
); 

if($stmt->execute($data)){ 
    $rows_affected = $stmt->rowCount(); 
    echo "<h2>".$rows_affected." row updated sucessfully!</h2>"; 

    display("SELECT person_id, name, date_of_birth, active_start_year, 
                    active_end_year, bio_url, domain_id, nationality_id
             FROM Person
             ORDER BY person_id");
}
else 
{ 
	echo "update failed: (" . $conn->errno . ") " . $conn->error; 
}
$conn->close(); 
?>


