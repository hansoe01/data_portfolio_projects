<?php
include_once 'dbstars.php';
include_once 'person_display.php';

# form data
$name              = trim($_POST['name']);
$date_of_birth     = trim($_POST['date_of_birth']);
$active_start_year = trim($_POST['active_start_year']);
$active_end_year   = trim($_POST['active_end_year']);
$bio_url           = trim($_POST['bio_url']);
$domain_id         = trim($_POST['domain_id']);
$nationality_id    = trim($_POST['nationality_id']);

# allow optional fields to be NULL (instead of empty string)
if ($active_end_year === "") { $active_end_year = null; }
if ($bio_url === "")         { $bio_url = null; }

$sql = "INSERT INTO Person
        (name, date_of_birth, active_start_year, active_end_year, bio_url, domain_id, nationality_id)
        VALUES
        (:name, :dob, :start_year, :end_year, :bio, :domain, :nation)";

$stmt = $conn->prepare($sql);

$data = array(
    'name'       => $name,
    'dob'        => $date_of_birth,
    'start_year' => $active_start_year,
    'end_year'   => $active_end_year,
    'bio'        => $bio_url,
    'domain'     => $domain_id,
    'nation'     => $nationality_id
);

if ($stmt->execute($data)) {
    $rows_affected = $stmt->rowCount();
    echo "<h2>" . $rows_affected . " row added sucessfully!</h2>";

    echo "<h3>Proof: Current Person Table</h3>";
    display("SELECT person_id, name, date_of_birth, active_start_year,
                    active_end_year, bio_url, domain_id, nationality_id
             FROM Person
             ORDER BY person_id");

    echo "<br><br><a href=\"insert_person_form.html\">Insert Another</a> | ";
    echo "<a href=\"index.html\">Back to Home</a>";
}
else {
    echo "\nPDOStatement::errorInfo():\n";
    print_r($stmt->errorInfo());
}

$stmt = null;
$conn = null;
?>
