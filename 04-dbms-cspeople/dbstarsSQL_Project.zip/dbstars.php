<?php // dbstars.php 

$host = "localhost"; 
$dbname = "jc45db"; 
$user = "jc45";   
$pass = ""; 

try { 
	// Create the PDO connection object
	$conn = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass); 
	
	// Set the error mode to throw exceptions on failure (best practice)
	$conn->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION ); 
}
catch(PDOException $e) { 
	// Terminate script execution and display the connection error
	die("Could not connect to the database $dbname :" . $e->getMessage()); 
}
// Connection established, $conn variable is now available for other files
?>