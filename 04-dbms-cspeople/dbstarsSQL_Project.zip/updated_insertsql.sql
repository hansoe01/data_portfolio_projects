SET FOREIGN_KEY_CHECKS = 0;

-- 1. TRUNCATE (RESET) TABLES
-- This resets the Auto-Increment counters to 1.
TRUNCATE TABLE Authorship;
TRUNCATE TABLE Affiliation;
TRUNCATE TABLE PersonAward;
TRUNCATE TABLE OtherContributions;
TRUNCATE TABLE ManagementLog;
TRUNCATE TABLE Works;          
TRUNCATE TABLE Organization;
TRUNCATE TABLE Award;
TRUNCATE TABLE Contributions;
TRUNCATE TABLE Person;
TRUNCATE TABLE Domain;
TRUNCATE TABLE Nationality;
TRUNCATE TABLE User;

SET FOREIGN_KEY_CHECKS = 1;


-- 2. INSERT USERS & LOOKUPS
INSERT INTO User (username, password, access_level) VALUES ('sysadmin', 'hashed_pass', 'admin');

INSERT INTO Nationality (name) VALUES 
('Finnish'), ('Hungarian-American'), ('British'), ('American'), ('Dutch'), ('Israeli-American');

INSERT INTO Domain (name) VALUES 
('Operating Systems'), ('Mathematics'), ('Theoretical Computer Science'), ('Technology'), ('Software Engineering'), ('Programming Languages'), ('Computer Programming');


-- 3. INSERT ORGANIZATIONS
INSERT INTO Organization (name, country, org_type, url) VALUES
  ('Transmeta Corporation', 'USA', 'Industry', NULL),        -- ID 1
  ('Institute for Advanced Study', 'USA', 'Academic', NULL), -- ID 2
  ('University of Cambridge', 'UK', 'Academic', NULL),       -- ID 3
  ('Microsoft', 'USA', 'Industry', NULL),                    -- ID 4
  ('NASA', 'USA', 'Government', NULL),                       -- ID 5
  ('Python Software Foundation', 'USA', 'Non-profit', NULL), -- ID 6
  ('MIT', 'USA', 'Academic', NULL),                          -- ID 7
  ('NACA', 'USA', 'Government', NULL),                       -- ID 8
  ('Apple Inc.', 'USA', 'Industry', NULL),                   -- ID 9
  ('US Navy', 'USA', 'Government', NULL);                    -- ID 10


-- 4. INSERT PEOPLE
INSERT INTO Person (name, date_of_birth, active_start_year, active_end_year, bio_url, domain_id, nationality_id) VALUES
  ('Linus Torvalds', '1969-12-28', 1988, 2024, 'http://torvalds.bio', 1, 1),
  ('John von Neumann', '1903-12-28', 1926, 1957, 'http://vonneumann.bio', 2, 2),
  ('Alan Turing', '1912-06-23', 1935, 1954, 'http://turing.bio', 3, 3),
  ('Bill Gates', '1955-10-28', 1975, 2024, 'http://gates.bio', 4, 4),
  ('Margaret Hamilton', '1936-08-17', 1961, 2024, 'http://hamilton.bio', 5, 4),
  ('Guido van Rossum', '1956-01-31', 1989, 2024, 'http://gvr.bio', 6, 5),
  ('Steve Jobs', '1955-02-24', 1976, 2011, 'http://jobs.bio', 4, 4),
  ('Grace Hopper', '1906-12-09', 1944, 1986, 'http://hopper.bio', 7, 4),
  ('Shafi Goldwasser', '1958-06-18', 1983, 2018, 'http://goldwasser.bio', 3, 6),
  ('Katherine Johnson', '1918-08-26', 1953, 1986, 'http://johnson.bio', 2, 4);


-- 5. INSERT WORKS (Using 'Works' Plural)
INSERT INTO Works (title, pub_year, work_type, url) VALUES
  ('Linux Kernel', 1991, 'software', NULL),         -- ID 1
  ('First Draft on EDVAC', 1945, 'report', NULL),   -- ID 2
  ('On Computable Numbers', 1936, 'paper', NULL),   -- ID 3
  ('Microsoft Windows', 1985, 'software', NULL),    -- ID 4
  ('Apollo Guidance Code', 1969, 'software', NULL), -- ID 5
  ('Python Language', 1991, 'software', NULL),      -- ID 6
  ('Macintosh OS', 1984, 'software', NULL),         -- ID 7
  ('Compilers Paper', 1952, 'paper', NULL),         -- ID 8
  ('Lattice Problems', 2002, 'book', NULL),         -- ID 9
  ('Apollo Trajectory', 1969, 'report', NULL);      -- ID 10

-- Link Works (1-to-1 Mapping)
-- Since TRUNCATE Works succeeded this time, IDs will be 1-10.
INSERT INTO Authorship (person_id, work_id) VALUES 
  (1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6), (7, 7), (8, 8), (9, 9), (10, 10);


-- 6. INSERT AWARDS
INSERT INTO Award (award_name, category) VALUES
  ('Millennium Tech Prize', 'Tech'),     -- ID 1
  ('Fermi Award', 'Science'),            -- ID 2
  ('Turing Award', 'CS'),                -- ID 3
  ('Medal of Freedom', 'Civilian'),      -- ID 4
  ('NASA Space Act Award', 'Space'),     -- ID 5
  ('Free Software Award', 'CS'),         -- ID 6
  ('National Medal of Tech', 'Tech'),    -- ID 7
  ('Defense Medal', 'Military'),         -- ID 8
  ('Godel Prize', 'CS'),                 -- ID 9
  ('Congressional Gold Medal', 'Civilian'); -- ID 10

INSERT INTO PersonAward (person_id, award_id, award_year) VALUES
  (1, 1, 2012), 
  (2, 2, 1956), 
  (3, 3, 1966), 
  (4, 4, 2016), 
  (5, 5, 2003),
  (6, 6, 2001), 
  (7, 7, 1985), 
  (8, 8, 1986), 
  (9, 9, 1993), 
  (10, 10, 2019);


-- 7. INSERT AFFILIATIONS
INSERT INTO Affiliation (person_id, org_id, title, active_start_year, active_end_year) VALUES
  (1, 1, 'Chief Architect', 1997, 2003), 
  (2, 2, 'Professor', 1933, 1957),
  (3, 3, 'Fellow', 1935, 1954),
  (4, 4, 'CEO', 1975, 2000),
  (5, 5, 'Director', 1961, 1976),
  (6, 6, 'President', 2001, 2018),
  (7, 9, 'CEO', 1976, 2011),
  (8, 10, 'Rear Admiral', 1943, 1986),
  (9, 7, 'Professor', 1983, 2018),
  (10, 8, 'Mathematician', 1953, 1986);


-- 8. INSERT CONTRIBUTIONS
INSERT INTO Contributions (name, year, type) VALUES
  ('Open Source Movement', 1991, 'other'),          -- ID 1
  ('Game Theory', 1944, 'theory'),                  -- ID 2
  ('Code Breaking', 1940, 'practice'),              -- ID 3
  ('Personal Computing', 1975, 'business'),         -- ID 4
  ('Software Engineering', 1969, 'practice'),       -- ID 5
  ('Readability in Code', 1991, 'theory'),          -- ID 6
  ('Smartphone Revolution', 2007, 'business'),      -- ID 7
  ('COBOL Language', 1959, 'software'),             -- ID 8
  ('Zero-Knowledge Proofs', 1985, 'theory'),        -- ID 9
  ('Orbital Mechanics', 1962, 'math');              -- ID 10

INSERT INTO OtherContributions (person_id, cont_id) VALUES
  (1, 1), (2, 2), (3, 3), (4, 4), (5, 5), (6, 6), (7, 7), (8, 8), (9, 9), (10, 10);